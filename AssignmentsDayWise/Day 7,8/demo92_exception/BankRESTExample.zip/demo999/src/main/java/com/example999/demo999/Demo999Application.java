package com.example999.demo999;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.example999.demo999.repo.BankRepository;

@SpringBootApplication
//@ComponentScan({"com.example999.demo999","com.example999.demo999.controller"})
public class Demo999Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo999Application.class, args);
	}
}

/*@Configuration
class MyConfiguration{
	@Bean
	@Primary
	BankRepository getbr(){
		return new BankRepository();
	}
}*/

