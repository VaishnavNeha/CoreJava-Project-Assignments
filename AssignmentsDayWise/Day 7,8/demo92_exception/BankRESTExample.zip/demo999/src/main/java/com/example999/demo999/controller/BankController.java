package com.example999.demo999.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example999.demo999.model.BankAccount;
import com.example999.demo999.service.BankService;


@RestController //@Component
public class BankController {

	@Autowired
	BankService bService;
	
	@GetMapping("/")
	String met(){
		return "Hello World!!!";
	}

	//converting JSON to Java object - DeSerilization
	@PostMapping("/create")
	int createAccount(@RequestBody BankAccount bAccount){
		System.out.println("Received Bank Account:"+bAccount);
		
		return bService.createAccount(bAccount).getBid();
	}
	
	//retrieve a specific BankAccount details
	// /id/10/20
	// /id?bid=10&abal=20
	@GetMapping("/id")
	BankAccount retrieve(@RequestParam("bid") int bid){
		//retrieve bank account from db
		Optional<BankAccount> bAccount = bService.fetchAccount(bid);
		return bAccount.get();
	}
	
	
	//delete a Bank account
	
	//update Bank Account
	
}
